﻿using System;
using System.Diagnostics;
using NUnit.Framework;
using W11_Prove;

namespace UnitTests
{
    /// <summary>
    /// Performance test suite for AQueue<T> operations.
    /// Measures execution time of queue operations at various loads using Stopwatch.
    /// Timing is recorded in ticks for precise performance analysis.
    /// </summary>
    [TestFixture]
    public class PerformanceTests
    {
        /// <summary>
        /// Tests the performance of Enqueue operation at increasing queue sizes.
        /// Purpose: Verify that Enqueue maintains O(1) complexity regardless of queue size.
        /// 
        /// 
        /// Expected Result: Enqueue time should increase roughly linearly with size,
        /// demonstrating O(1) per operation (constant time per item).
        /// </summary>
        [TestCase(10000)] // Small load baseline
        [TestCase(20000)] // Medium load
        [TestCase(30000)] // Medium-large load
        [TestCase(40000)] // Large load
        [TestCase(50000)] // Large load continued
        [TestCase(60000)] // Large load peak
        [TestCase(6000000)] // Stress test for extreme load handling and why not try a big load?
        public void Enqueue_Performance(int size)
        {
            var q = new AQueue<int>(size);
            var stopwatch = Stopwatch.StartNew();

            // Perform Enqueue operation 'size' times
            for (int i = 0; i < size; i++)
                q.Enqueue(i);

            stopwatch.Stop();
            TestContext.WriteLine($"Enqueue {size} items: {stopwatch.ElapsedTicks} ticks");
        }

        /// <summary>
        /// Tests the performance of Dequeue operation at various queue sizes.
        /// Purpose: Verify that Dequeue maintains O(1) complexity regardless of queue size.
        /// 
        /// Test Parameters:
        /// - 1,000 items: Small load baseline
        /// - 10,000 items: Medium load
        /// - 50,000 items: Large load
        /// 
        /// Expected Result: Dequeue time should increase linearly with size,
        /// demonstrating O(1) per operation (constant time per item).
        /// </summary>
        [TestCase(1000)]    // Small load baseline
        [TestCase(10000)]   // Medium load
        [TestCase(50000)]   // Large load
        public void Dequeue_Performance(int size)
        {
            // First, fill the queue with items
            var q = new AQueue<int>(size);
            for (int i = 0; i < size; i++)
                q.Enqueue(i);

            // Measure time for Dequeue operations
            var stopwatch = Stopwatch.StartNew();
            for (int i = 0; i < size; i++)
                q.Dequeue();

            stopwatch.Stop();
            TestContext.WriteLine($"Dequeue {size} items: {stopwatch.ElapsedTicks} ticks");
        }

        /// <summary>
        /// Tests the performance of Peek operation at a fixed queue size.
        /// Purpose: Verify that Peek maintains O(1) complexity.
        /// 
        /// Test Parameters:
        /// - 10,000 queue size with 10,000 Peek operations
        /// 
        /// Expected Result: Peek operations should be very fast since they don't modify
        /// the queue and only access the front element. Time should be minimal.
        /// </summary>
        [TestCase(10000)]   // 10,000 items in queue, peeked 10,000 times
        public void Peek_Performance(int size)
        {
            // Fill the queue with items
            var q = new AQueue<int>(size);
            for (int i = 0; i < size; i++)
                q.Enqueue(i);

            // Measure time for Peek operations (size times)
            var stopwatch = Stopwatch.StartNew();
            for (int i = 0; i < size; i++)
                q.Peek();

            stopwatch.Stop();
            TestContext.WriteLine($"Peek {size} times: {stopwatch.ElapsedTicks} ticks");
        }

        /// <summary>
        /// Tests the performance of Contains operation at a fixed queue size.
        /// Purpose: Verify that Contains operations perform efficiently and demonstrate O(n) complexity.
        /// 
        /// Test Parameters:
        /// - 10,000 items in queue
        /// - 100 Contains searches (searching near the end of the queue)
        /// 
        /// Expected Result: Contains should be slower than Peek/Dequeue since it searches
        /// through the queue. Time should increase with queue size due to O(n) complexity.
        /// </summary>
        [TestCase(10000)]   // 10,000 items in queue, searched 100 times
        public void Contains_Performance(int size)
        {
            // Fill the queue with items
            var q = new AQueue<int>(size);
            for (int i = 0; i < size; i++)
                q.Enqueue(i);

            // Measure time for Contains operations (100 searches near the end of the queue)
            var stopwatch = Stopwatch.StartNew();
            for (int i = 0; i < 100; i++)
                q.Contains(size - i);  // Search for items near the end

            stopwatch.Stop();
            TestContext.WriteLine($"Contains 100 times: {stopwatch.ElapsedTicks} ticks");
        }
    }
}
