﻿using NUnit.Framework;
using W11_Prove;

namespace UnitTests
{
    /// <summary>
    /// Functional test suite for AQueue<T> implementation.
    /// Tests all core queue operations and edge cases to ensure correctness.
    /// </summary>
    [TestFixture]
    public class QueueTests
    {
        /// <summary>
        /// Test: Enqueue and Dequeue work correctly with proper size tracking.
        /// 
        /// Purpose: Verify basic queue functionality - adding and removing items,
        /// and that the Size property correctly reflects the number of items.
        /// 
        /// Setup: Create a queue with capacity 5
        /// Action: Enqueue 10 and 20, verify size is 2, Dequeue (should return 10)
        /// Expected Result: Size updates correctly after each operation (2 → 1)
        /// and items are removed in FIFO order.
        /// </summary>
        [Test]
        public void EnqueueDequeue_WorksCorrectly()
        {
            var q = new AQueue<int>(5);
            q.Enqueue(10);
            q.Enqueue(20);

            Assert.That(q.Size, Is.EqualTo(2));
            Assert.That(q.Dequeue(), Is.EqualTo(10));
            Assert.That(q.Size, Is.EqualTo(1));
        }

        /// <summary>
        /// Test: Peek returns the front item without removing it.
        /// 
        /// Purpose: Verify that Peek operation allows viewing the front item
        /// without modifying the queue state.
        /// 
        /// Setup: Create a queue and enqueue value 42
        /// Action: Call Peek and check that Size remains unchanged
        /// Expected Result: Peek returns 42 and Size remains 1 (item not removed)
        /// </summary>
        [Test]
        public void Peek_ReturnsFrontWithoutRemoving()
        {
            var q = new AQueue<int>(5);
            q.Enqueue(42);

            Assert.That(q.Peek(), Is.EqualTo(42));
            Assert.That(q.Size, Is.EqualTo(1));
        }

        /// <summary>
        /// Test: Contains method correctly finds and doesn't find items.
        /// 
        /// Purpose: Verify that the Contains method can search for items in the queue
        /// and correctly identify both present and absent items.
        /// 
        /// Setup: Create a queue and enqueue values 1, 2, and 3
        /// Action: Search for value 2 (should exist) and 99 (should not exist)
        /// Expected Result: Contains returns true for 2 and false for 99
        /// </summary>
        [Test]
        public void Contains_FindsItems()
        {
            var q = new AQueue<int>(5);
            q.Enqueue(1);
            q.Enqueue(2);
            q.Enqueue(3);

            Assert.That(q.Contains(2), Is.True);
            Assert.That(q.Contains(99), Is.False);
        }

        /// <summary>
        /// Test: Enqueue throws InvalidOperationException when queue is full.
        /// 
        /// Purpose: Verify that the queue properly enforces capacity constraints
        /// and throws an appropriate exception when attempting to exceed capacity.
        /// 
        /// Setup: Create a queue with capacity 2
        /// Action: Enqueue two items (filling the queue), then attempt to enqueue a third
        /// Expected Result: InvalidOperationException is thrown on the third Enqueue
        /// </summary>
        [Test]
        public void Enqueue_FullQueue_ThrowsException()
        {
            var q = new AQueue<int>(2);
            q.Enqueue(1);
            q.Enqueue(2);

            Assert.Throws<InvalidOperationException>(() => q.Enqueue(3));
        }

        /// <summary>
        /// Test: Dequeue throws InvalidOperationException when queue is empty.
        /// 
        /// Purpose: Verify that Dequeue properly validates queue state and throws
        /// an appropriate exception when attempting to remove from an empty queue.
        /// 
        /// Setup: Create an empty queue (no items enqueued)
        /// Action: Attempt to Dequeue from the empty queue
        /// Expected Result: InvalidOperationException is thrown
        /// </summary>
        [Test]
        public void Dequeue_EmptyQueue_ThrowsException()
        {
            var q = new AQueue<int>(2);
            Assert.Throws<InvalidOperationException>(() => q.Dequeue());
        }

        /// <summary>
        /// Test: Peek throws InvalidOperationException when queue is empty.
        /// 
        /// Purpose: Verify that Peek properly validates queue state and throws
        /// an appropriate exception when attempting to view front of empty queue.
        /// 
        /// Setup: Create an empty queue (no items enqueued)
        /// Action: Attempt to Peek at the empty queue
        /// Expected Result: InvalidOperationException is thrown
        /// </summary>
        [Test]
        public void Peek_EmptyQueue_ThrowsException()
        {
            var q = new AQueue<int>(2);
            Assert.Throws<InvalidOperationException>(() => q.Peek());
        }

        /// <summary>
        /// Test: Queue operations work correctly with circular buffer wrap-around.
        /// 
        /// Purpose: Verify that the queue correctly handles the circular buffer behavior
        /// when front and rear pointers wrap around the end of the backing array.
        /// 
        /// Setup: Create a queue with capacity 3
        /// Action: 
        ///   - Enqueue 1, 2, 3 (queue is full)
        ///   - Dequeue (removes 1, front pointer moves)
        ///   - Enqueue 4 (rear pointer wraps to beginning)
        /// Expected Result: Contains finds 2, 3, and 4 - all items are in correct positions
        /// despite the circular buffer wrap-around
        /// </summary>
        [Test]
        public void WrapAround_WorksCorrectly()
        {
            var q = new AQueue<int>(3);
            q.Enqueue(1);
            q.Enqueue(2);
            q.Enqueue(3);
            q.Dequeue();
            q.Enqueue(4);

            Assert.That(q.Contains(2), Is.True);
            Assert.That(q.Contains(3), Is.True);
            Assert.That(q.Contains(4), Is.True);
        }
    }
}
