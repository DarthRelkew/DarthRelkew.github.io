using System;

namespace W11_Prove
{
    /// <summary>
    /// Generic Queue implementation using a fixed-size circular buffer.
    /// 
    /// This queue uses a circular buffer approach with _front and _rear pointers
    /// to efficiently manage enqueue and dequeue operations in O(1) time.
    /// The queue cannot grow beyond its initial capacity.
    /// </summary>
    /// <typeparam name="T">The type of items stored in the queue</typeparam>
    public class AQueue<T>   
    {
        private readonly T[] _items;   // Fixed-size array backing the queue
        private int _front;            // Index pointing to the front of the queue
        private int _rear;             // Index pointing to the next available position
        private int _size;             // Current number of items in the queue
        
        /// <summary>
        /// Initializes a new instance of AQueue with the specified capacity.
        /// </summary>
        /// <param name="capacity">The maximum number of items the queue can hold</param>
        /// <exception cref="ArgumentException">Thrown when capacity is less than or equal to 0</exception>
        public AQueue(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentException("Capacity must be greater than zero");
            _items = new T[capacity];
            _front = 0;
            _rear = 0;
            _size = 0;
        }

        /// <summary>
        /// Gets the current number of items in the queue.
        /// </summary>
        public int Size => _size;

        /// <summary>
        /// Adds an item to the back of the queue.
        /// 
        /// Time Complexity: O(1) - Constant time operation
        /// 
        /// This method uses the circular buffer approach: when rear reaches the end
        /// of the array, it wraps around to the beginning using modulo arithmetic.
        /// </summary>
        /// <param name="item">The item to add to the queue</param>
        /// <exception cref="InvalidOperationException">Thrown when the queue is full</exception>
        public void Enqueue(T item)
        {
            if (_size == _items.Length)
                throw new InvalidOperationException("The queue is full");
            _items[_rear] = item;
            _rear = (_rear + 1) % _items.Length;  // Wrap around to beginning if necessary
            _size++;
        }

        /// <summary>
        /// Removes and returns the item at the front of the queue.
        /// 
        /// Time Complexity: O(1) - Constant time operation
        /// 
        /// Uses the circular buffer approach: when front reaches the end of the array,
        /// it wraps around to the beginning using modulo arithmetic.
        /// </summary>
        /// <returns>The item that was at the front of the queue</returns>
        /// <exception cref="InvalidOperationException">Thrown when the queue is empty</exception>
        public T Dequeue()
        {
            if (_size == 0)
                throw new InvalidOperationException("The queue is empty");
            
            T value = _items[_front];
            _front = (_front + 1) % _items.Length;  // Wrap around to beginning if necessary
            _size--;
            return value;
        }

        /// <summary>
        /// Returns the item at the front of the queue without removing it.
        /// 
        /// Time Complexity: O(1) - Constant time operation
        /// 
        /// This method does not modify the queue state.
        /// </summary>
        /// <returns>The item at the front of the queue</returns>
        /// <exception cref="InvalidOperationException">Thrown when the queue is empty</exception>
        public T Peek()
        {
            if (_size == 0)
                throw new InvalidOperationException("The queue is empty");
            
            return _items[_front];
        }

        /// <summary>
        /// Searches for an item in the queue.
        /// 
        /// Time Complexity: O(n) - Linear time, where n is the number of items in the queue
        /// 
        /// This method accounts for the circular buffer by calculating the actual index
        /// using (_front + i) % _items.Length for each position.
        /// </summary>
        /// <param name="item">The item to search for</param>
        /// <returns>True if the item is found in the queue; otherwise, false</returns>
        public bool Contains(T item)
        {
            for (int i = 0; i < _size; i++)
            {
                // Calculate actual index accounting for circular wrap-around
                int index = (_front + i) % _items.Length;
                if (Equals(_items[index], item))
                    return true;
            }
            return false;
        }
    }
}
